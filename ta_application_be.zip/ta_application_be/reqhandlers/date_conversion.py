from datetime import date, datetime, timedelta

def json_serial(obj):
    # JSON serializer for objects not serializable by default json code
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    elif isinstance(obj, timedelta):
        return str(obj)
    raise TypeError(f"Type {type(obj)} not serializable")