from functools import wraps
from flask import jsonify
from flask_jwt_extended import jwt_required, get_jwt
from core.dbil import dbilayer


def authenticate_and_authorize(allowed_roles):
    def wrapper(func):
        @jwt_required()
        @wraps(func)
        def wrapped(*args, **kwargs):
            jwt_info=get_jwt()
            user_email=''
            if (len(jwt_info) != 0):
                user_email=get_jwt()['sub']
                print(user_email,"======USERNAME=================>>>>")
            email_dict={}
            email_dict['user_email']=user_email  #Converting into dictionary format because dbilayer function here in this project is accepting as dictionary
            user_details = dbilayer.get_specific_filed('users', 'role' , email_dict)
            if ((user_details is None) or (isinstance(user_details, str))):
                return jsonify({"response":{"message": "User doesn't exist or User status inactive or error occured in database"}})
            if (user_details['role'] not in allowed_roles):
                return jsonify({"response":{"message": "User doesn't have proper permission"}})
            return func(*args, **kwargs)
        return wrapped
    return wrapper    
