import datetime
from datetime import datetime, timedelta,timezone
import pickle
import os.path
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
import smtplib, ssl
from smtplib import SMTP          
from googleapiclient.errors import HttpError
# from reqhandlers.email_utils import send_email
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.mime.text import MIMEText
from email.message import EmailMessage
from reqhandlers.handling_datetime import get_current_timestamp
from reqhandlers.cal_setup import get_calendar_service
# from reqhandlers.create_meet_link import meetLink_get
from flask import Flask, request, jsonify
from core.bll import bllengine

import pytz
tz_UTC = pytz.timezone('UTC')
import base64
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText


# from cal_setup import get_calendar_service

# If modifying these scopes, delete the file token.pickle.
SCOPES = ['https://www.googleapis.com/auth/calendar','https://www.googleapis.com/auth/gmail.send']

CREDENTIALS_FILE = 'credentials.json'

## This function to create instance for google meet
def get_calendar_service():
   creds = None
   # The file token.pickle stores the user's access and refresh tokens, and is
   # created automatically when the authorization flow completes for the first
   # time.
   if os.path.exists('token.pickle'):
       with open('token.pickle', 'rb') as token:
           creds = pickle.load(token)
   # If there are no (valid) credentials available, let the user log in.
   if not creds or not creds.valid:
       if creds and creds.expired and creds.refresh_token:
           creds.refresh(Request())
       else:
           flow = InstalledAppFlow.from_client_secrets_file(
               CREDENTIALS_FILE, SCOPES)
           creds = flow.run_local_server(port=0)

       # Save the credentials for the next run
       with open('token.pickle', 'wb') as token:
           pickle.dump(creds, token)

   service = build('calendar', 'v3', credentials=creds)
   return service
    

## This function is to create Google event
def create_event(request_data):
    try:
        print("Request data in function",request_data)
        print("start,end",get_current_timestamp(),request_data['end_time']+"05:30")
        print("attendees_list",[{'email': attendee_details['email']} for attendee_details in request_data['attendees']])
        service = get_calendar_service()
        event_result = service.events().insert(calendarId='primary',
            body={
                 "summary": request_data['summary'],
                'params' :{
        'sendNotifications': True
        },
                'location': request_data['location'],
                "description": request_data['description'],
                
                #  "start": {"dateTime": get_current_timestamp(), "timeZone": 'Asia/Kolkata'},
                # "start.date	":request_data['start.date'],
              
                "start": {"dateTime": request_data['start_time']+"+05:30", "timeZone": 'Asia/Kolkata'},


                "end": {"dateTime": request_data['end_time']+"+05:30", "timeZone": 'Asia/Kolkata'},
                 
                'attendees': [{'email': attendee_details['email']} for attendee_details in request_data['attendees']],
                 'guestsCanSeeOtherGuests' :False,
            'conferenceData': {
                'createRequest': {
                'requestId': 'sample123',  
                'conferenceSolutionKey': {
                    'type': 'hangoutsMeet'
                }
            }
        }
            },conferenceDataVersion=1, sendUpdates='all'
        ).execute()
        googlemeetId=event_result['id']
        meetlink_id= '-'.join(event_result.get('conferenceData', {}).get('conferenceId').split('-')[:3])
        print("Google Calendar event created Succesfully")
        meetlink = "https://meet.google.com/{}".format(meetlink_id)
        # print("id: ", event_result.get('conferenceData', {}).get('conferenceId'))
        print("id: ", googlemeetId)
        print("summary: ", event_result['summary'])
        print("start: ", event_result['start']['dateTime'])
        print("end: ", event_result['end']['dateTime'])
        print("All events are created successfully")

        # for attendee_details in request_data['attendees']:
        #     send_email_to_user(attendee_details,event_result)

        return {"message":"Success","meet_link":meetlink,"event_id":googlemeetId}
        
    except Exception as err:
        print("error to create meet is ", err)
        return {"message":"Failed"}
    
# #### Event Update #####



### Event Update #####
# def update_event(request_data):
#         # update the event to tomorrow 9 AM IST
#     try:
#         service = get_calendar_service()
#         d = datetime.now().date()
#         tomorrow = datetime(d.year, d.month, d.day, 9)+timedelta(days=1)
#         event_result = service.events().update(
#           calendarId='primary',
#           eventId=request_data['googlemeet_id'],
#       body={
#            "summary": request_data['summary'],
#            'params' :{
#     'sendNotifications': True
#   },
#            'location': request_data['location'],
#            "description": request_data['description'],
#            "start": {"dateTime": request_data['start']+"+05:30", "timeZone": 'Asia/Kolkata'},


#             "end": {"dateTime": request_data['end']+"+05:30", "timeZone": 'Asia/Kolkata'},
           
#            'attendees': [
#             {'email':'suresh.kondru@machint.com'
      
#               }   
#         ],
    
#         'conferenceData': {
#            'createRequest': {
#             'requestId': 'sample123',  
#             'conferenceSolutionKey': {
#                 'type': 'hangoutsMeet'
#             }
#         }
#     }
#        },conferenceDataVersion=1, sendUpdates='all'
#    ).execute()

#         print("updated event")
#         print("id: ", event_result['id'])
#         print("summary: ", event_result['summary'])
#         print("starts at: ", event_result['start']['dateTime'])
#         print("ends at: ", event_result['end']['dateTime'])

#         return True
        
#     except Exception as err:
#         print("error to create meet is ", err)
#         return False


#####Event Cancel/Delete#######
def cancel_event_and_send_email(req_data):
    try:
        sender_email = "ta.dev@machint.com"
        receiver_email = req_data["email"]
        password = "Machint@dev2024"
        candidate_name = req_data["candidate_name"]
        interviewer_name = req_data["interviewer_name"]
        date = req_data["date"]
        start_time = req_data["start_time"]
        end_time = req_data["end_time"]
        interview_round = req_data["round_name"]
         
        message = MIMEMultipart()
        message['From'] = sender_email
        message['To'] = receiver_email
        message['Subject'] = "{} Discussion with Machint Solutions Pvt has been cancelled!".format(interview_round)

        body = (
                f"""\
                Hi {candidate_name},
        
                We would like to inform you that, your interview round schedule for {date} at {start_time} with {interviewer_name} has been cancelled. 
                Our team will reach out to you for next steps.

                Regards,
                TA MACHINT,
                Machint Solutions Pvt Ltd""")
        message.attach(MIMEText(body, 'plain'))

        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, password)
        text = message.as_string()
        server.sendmail(sender_email, receiver_email, text)
        server.quit()
        output = "Success"
        return output
    except Exception as e:
        print(e)
        output = "Failed"
        return output

def cancel_event(request_data):
    service = get_calendar_service()

    try:
           service.events().delete(
               calendarId="primary",
               eventId=request_data['googlemeet_id'],
           ).execute()
           output = "Success"
           return output
    # except googleapiclient.errors.HttpError:
    except HttpError as error:
            print(str(error),"========the error")
            output = "Failed"
            return output

######UPDATE EVENT AND SEND EMAIL ###########
 
def update_event_and_send_email(req_data):
    try:
        print("Called mail send==============",req_data)
        sender_email = "ta.dev@machint.com"
        receiver_email = req_data["email"]
        password = "Machint@dev2024"
        candidate_name = req_data["candidate_name"]
        interviewer_name = req_data["interviewer_name"]
        date = req_data["date"]
        start_time = req_data["start_time"]
        end_time = req_data["end_time"]
        interview_round = req_data["round_name"]
        location = req_data["location"]
        
 
        message = MIMEMultipart()
        message['From'] = sender_email
        message['To'] = receiver_email
        message['Subject'] = "{} Discussion with Machint Solutions Pvt has been Updated!".format(interview_round)

        body = (
                f"""\
                Hi {candidate_name},
        
                We would like to inform you that, your interview round schedule for {date} at {start_time} with {interviewer_name} has been Updated. 
                Join with this googlemeet invite link :- {location}
                

                Regards,
                TA MACHINT,
                Machint Solutions Pvt Ltd""")
         
        message.attach(MIMEText(body, 'plain'))
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, password)
        text = message.as_string()
        server.sendmail(sender_email, receiver_email, text)
        server.quit()
        output = "Success"
        return output
    except Exception as e:
        print(e)
        output = "Failed"
        return output
 
def update_event(request_data):
        # update the event t 
    try:
        service = get_calendar_service()
         
        event_result = service.events().update(
          calendarId='primary',
          eventId=request_data['googlemeet_id'],
      body={
           "summary": request_data['summary'],
           'params' :{
    'sendNotifications': True
  },
           'location': request_data['location'],
           "description": request_data['description'],
            'guestsCanSeeOtherGuests' :False,

            "start": {"dateTime":  request_data['date']+'T'+request_data['start_time']+"+05:30", "timeZone": 'Asia/Kolkata'},

            "end": {"dateTime":request_data['date']+'T'+request_data['end_time']+"+05:30", "timeZone": 'Asia/Kolkata'},
            
            'attendees': [{'email': attendee_details['email']} for attendee_details in request_data['attendees']],

    
        'conferenceData': {
           'createRequest': {
            'requestId': 'sample123',  
            'conferenceSolutionKey': {
                'type': 'hangoutsMeet'
            }
        }
    }
       },conferenceDataVersion=1, sendUpdates='all'
   ).execute()
        googlemeetId=event_result['id']
        meetlink_id= '-'.join(event_result.get('conferenceData', {}).get('conferenceId').split('-')[:3])
        print("Google Calendar event created Succesfully")
        meetlink = "https://meet.google.com/{}".format(meetlink_id)
        output = {"message":"Success","location":meetlink}
        return output

        # print("updated event")
        # print("id: ", event_result['id'])
        # print("summary: ", event_result['summary'])
        # print("starts at: ", event_result['start']['dateTime'])
        # print("ends at: ", event_result['end']['dateTime'])

         
    except Exception as err:
        print("error to update meet is ", err)
        output = {"message":"Falied"}
        return output
    

 


    



################ Upcoming Events #####################
 
#####################################################

def upcoming_events(request_data):
    try:
        service = get_calendar_service()
        now = datetime.utcnow().isoformat() + 'Z'  # 'Z' indicates UTC time
        print('Getting Upcoming events')
        events_result = service.events().list(
            calendarId=request_data['calendarId'],  
            maxResults=10, 
            singleEvents=True, 
            timeMin=now,
            orderBy='startTime'
        ).execute()
        events = events_result.get('items', [])
        if not events:
            print('No upcoming events found.')
        for event in events:
            start = event['start'].get('dateTime', event['start'].get('date'))
            print(start, event['summary'])
        return True
    except Exception as err:
        print("error to create meet is ", err)
        return True

######################################################

 ###Generate email content#######

def content_email(request_data):
    # Extract data
    round_type = request_data.get('round_type')
    round_name = request_data.get('round_name')
    # candidate_id = request_data.get('candidate_id')
    candidate_name = request_data.get('candidate_name')
    # interviewer_id = request_data.get('interviewer')
    sender_email = request_data.get('sender_email')
    date = request_data.get('date')
    start_time = request_data.get('start_time')
    end_time = request_data.get('end_time')
    # Interview_Location=request_data.get('location')
    template_question = request_data.get('template_question')

    mail_subject = f"Interview Invitation for {round_type} - {round_name}"

    if round_type =="Face to Face" :
        mail_body = (
                    f"""\
                    Dear {candidate_name},

                    Your Interview has been scheduled for the {round_type} round ({round_name}) on {date}.

                    Interview Details:
                    Interview Location:{Interview_Location}                 
                    Date: {date}
                    Time: {start_time} - {end_time}
                    Template Question: {template_question}

                    Please confirm your availability for the interview.

                    Best regards,
                    {sender_email}
                    """)
        out_put = {"mail_body":mail_body,"mail_subject":mail_subject,"status_code":200}
     
    elif round_type=='Virtual':
        candidate_condition = {"candidate_id":request_data["candidate_id"]}

        data_for_generate_link = {}
        data_for_generate_link["summary"] = request_data["summary"]
        data_for_generate_link['start']=request_data['date']+'T'+request_data['start_time']
        data_for_generate_link['end']=request_data['date']+'T'+request_data['end_time']
        candidate_data = bllengine.candidate_readAllCond(candidate_condition)
        if "status_code" in candidate_data["response"]:
            candidate_email = candidate_data["response"]["data"]["personal_email"]
            candidate_name = candidate_data["response"]["data"]["first_name"]+" "+candidate_data["response"]["data"]["middle_name"]+" "+candidate_data["response"]["data"]["last_name"]
            candidate_dict = {}
            candidate_dict["name_of_the_attendee"] = candidate_name
            candidate_dict["email"] = candidate_email


            attendes_list = [candidate_dict]

            interviewer_condition = {}
            interviewer_condition["interviewer"] = request_data["interviewer"]
            interviewer_data = bllengine.interviewer_readAllCond(interviewer_condition)
            if "status_code" in interviewer_data["response"]:
                interviewer_dict = {}
                interviewer_email = interviewer_data["response"]["data"]["interviewer_email"]
                interviewer_name = interviewer_data["response"]["data"]["interviewer"]
                interviewer_dict["name_of_the_attendee"] = interviewer_name
                interviewer_dict["email"] = interviewer_email
                attendes_list.append(interviewer_dict)
            
                data_for_generate_link["attendees"] = attendes_list
                google_link = create_event(data_for_generate_link)
                mail_subject = f"Interview Invitation for {round_type} - {round_name}"

                mail_body = (
                            f"""\
                    Dear {candidate_name},
                    Your Interview has been scheduled for the {round_type} round ({round_name}) on {date}.
                    Please join with the below link XXXXXXXXXXX(IT WILL GENERATE AFTER SUBMIT)

                    Interview Details:
                    Date: {date}
                    Time: {start_time} - {end_time}
                    Template Question: {template_question}
                    Please confirm your availability for the interview.
                    Best regards,
                    {sender_email}
                    """)

                out_put = {
                    "mail_subject": mail_subject,
                    "mail_body": mail_body,
                    "location":google_link
                }
            else:
                out_put = "Failed"
        else:
            out_put = "Failed"
    return out_put


 

##=====================================##
def send_mail_to_attendees(attendee_details):
    try:
        print("Attendee details", attendee_details)
        sender_email='ta.dev@machint.com'
        sender_password='Machint@dev2024'  
        subject = attendee_details["mail_subject"]      
        body = attendee_details["mail_body"]

        receiver_email= attendee_details['email']

        message = f'Subject:{subject}\n\n {body}'
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email,receiver_email, message)
        response="Success"
    except Exception as err:
        print("error message1......>",err)
        response="Failed"
        
    return response
    
 
         
# # Generate email content
# email_content = content_email(request_data)
# print(email_content)

####send email#############################
def send_email_to_user(attendee_details,event_result):
    try:
        print("Attendee details", attendee_details)
        sender_email='ta.dev@machint.com'
        sender_password='Machint@dev2024'        
        # sender_email = 'suresh.k0ndru2024@gmail.com'
         # sender_password = 'qrgstwzgfxnmafus'
        receiver_email= attendee_details['email']
 
        google_meet_id = '-'.join(event_result.get('conferenceData', {}).get('conferenceId').split('-')[:3])
        date_string = event_result['start']['dateTime']
        datetime_object = datetime.fromisoformat(date_string)

# Extracting date and time components

        date = datetime_object.date()
        time = datetime_object.time()
        message = 'Subject:Interview details Info with Machint Solutions pvt.Ltd\n\n Dear {},\n\n Greetings for the day.\n\nWe are glad to Inform you that Your interview is scheduled with Machint Solutions on {} at {} and you will receive an email with Google Invite\n\n Please connect with the following link \n\n https://meet.google.com/{} \n\n Thanks & Regards\nMachint Soltuions Private Limited\nHyderabad'.format(attendee_details['name_of_the_attendee'],date,time,google_meet_id)
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email,receiver_email, message)
        response="Success"
    except Exception as err:
        print("error message1......>",err)
        response="Failed"
        
    return response