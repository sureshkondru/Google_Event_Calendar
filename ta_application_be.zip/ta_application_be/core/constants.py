columns_users_table = "`employee_id`,`username`,`user_email`,`phone_number`,`password`,`role`,`status`,`user_photo`"
columns_otps_table = "`user_email`,`phone_number`,`otp`"
columns_job_opening_table="`job_type`,`job_title`,`employment_type`,`no_of_openings`,`seniority_level`,`job_function`,`customer`,`project`,`preferred_work_mode`,`company`,`business_unit`,`department`,`practice`,`designation`,`grade`,`region`,`branch`,`sub_branch`,`reporting_manager`,`job_description`,`job_attachment`,`min_years_exp`,`max_years_exp`,`qualification`,`currency`,`min_salary`,`max_salary`,`screening_criteria`,`is_urgent`,`approved_status`,`status`,`user_email`"
columns_interview_candidates_table = "`resume`,`prefix`,`full_name`,`middle_name`,`last_name`,`date_of_birth`,`gender`,`blood_group`,`nationality`,`personal_email`,`isd_code`,`phone_number`,`source`,`source_category`,`prefered_location`,`current_ctc`,`expected_ctc`,`notice_period`,`remarks`,`status`,`user_email`"
columns_scheduled_interviews_table = "`round_type`,`round_name`,`interviewer`,`date`,`start_time`,`end_time`,`candidate_id`,`interview_status`,`status`,`user_email`"
columns_employment_type_table = "`employment_type`,`status`"
columns_seniority_level_table = "`seniority_level`,`status`"
columns_job_function_table = "`job_function`,`status`"
columns_customer_table = "`customer`,`status`"
columns_project_table = "`project`,`status`"
columns_preferred_work_mode_table = "`preferred_work_mode`,`status`"
columns_business_unit_table = "`business_unit`,`status`"
columns_department_table ="`department`,`status`"
columns_practice_table = "`practice`,`status`"
columns_designation_table = "`designation`,`status`"
columns_grade_table = "`grade`,`status`"
columns_region_table = "`region`,`status`"
columns_branch_table = "`branch`,`status`"
columns_sub_branch_table = "`sub_branch`,`status`"
columns_qualification_table = "`qualification`,`status`"
columns_currency_table = "`currency`,`status`"
columns_prefix_table = "`prefix`,`status`"
columns_gender_table = "`gender`,`status`"
columns_blood_group_table = "`blood_group`,`status`"
columns_nationality_table = "`nationality`,`status`"
columns_isd_code_table = "`isd_code`,`status`"
columns_source_table = "`source`,`status`"
columns_source_category_table = "`source_category`,`status`"
columns_preferred_location_table = "`preferred_location`,`status`"
columns_notice_period_table = "`notice_period`,`status`"
columns_round_type_table = "`round_type`,`status`"
columns_template_table = "`template`,`description`,`status`"
columns_company_table = "`company`,`status`"
columns_interview_level_table = "`interview_level`,`status`"
columns_candidate_status_table = "`candidate_status`,`status`"
columns_employee_details_table ="`prefix`,`first_name`,`middle_name`,`last_name`,`employee_code`,`date_of_birth`,`gender`,`blood_group`,`nationality`,`work_email`,`isd_code`,`mobile_number`,`biometric_id`,`skill_type`,`date_of_joining`,`retirement_date`,`employment_type`,`employment_status`,`date_of_confirmation`,`employee_other_status_id`,`other_status_date`,`other_status_remarks`,`company`,`business_unit`,`department`,`practice`,`designation`,`region`,`branch`,`sub_branch`,`reporting_manager`,`line_hr`,`PAN_no`,`Aadhar_no`,`passport_no`,`passport_expiry_date`,`personal_email`,`emergency_contact_name`,`isd_code_emergency_contact`,`emergency_contact_no`,`relation`,`current_address`,`current_country`,`current_state`,`current_city`,`current_pin`,`permanent_address`,`permanent_country`,`permanent_state`,`permanent_city`,`permanent_pin`"






# print(columns_blood_group_table)



