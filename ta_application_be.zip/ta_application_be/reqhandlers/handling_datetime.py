from pytz import timezone 
from datetime import datetime

def get_current_timestamp():
    str_ind_time = datetime.now(timezone("Asia/Kolkata")).strftime('%Y-%m-%d %H:%M:%S')         # For the time being it is for Indian Time Zone 
    correct_time_format=datetime.strptime(str_ind_time, '%Y-%m-%d %H:%M:%S').isoformat()+"+05:30"
    
    return correct_time_format
print(get_current_timestamp(), type(get_current_timestamp()))