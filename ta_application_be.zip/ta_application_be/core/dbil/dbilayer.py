import mysql.connector
from werkzeug.security import generate_password_hash
from core.verifications import email_verification, username_verification, mobile_number_verification
from core import constants
# from hurry.filesize import size
from flask import current_app
import os, os.path
from dateutil.relativedelta import relativedelta
import datetime
from core.database_name import database_name
from core.bytes_to_gb_conversion import files_size_conversion
from core.sendemailtousers import send_opt_to_user_email_for_reset_password
import random

def return_specific_list_with_cond(field, tablename, condition,args=None):
    # db_connection = {
    #     'host':'10.11.12.102',
    #     'user':'ta_application',
    #     'passwd':'Machint@123',
    #     'database':'ta_application'
    #     }
    db_connection = {
        'host':'localhost',
        'user':'root',
        'passwd':'',
        'database':'ta_application',
        'port':3305

        }
    db_connection  = mysql.connector.connect(**db_connection)
    my_database=db_connection.cursor(dictionary=True)
    sql_query="SELECT {} FROM {} WHERE {}".format(field, tablename, condition)
    print(sql_query)
    final_stored_column_data_list=[]
    try:
        my_database.execute(sql_query, args)
        stored_column_data=my_database.fetchall()
        for name_dict in stored_column_data:
            final_stored_column_data_list.append(name_dict[field])
    except Exception as err:
        print("exception error message---->", err)
        final_stored_column_data_list=[]
    finally:    
        my_database.close()
        db_connection.close()
    return final_stored_column_data_list


def get_specific_filed(tablename, fields, userData):
    # db_connection = {
    #     'host':'10.11.12.102',
    #     'user':'ta_application',
    #     'passwd':'Machint@123',
    #     'database':'ta_application'
    #     }
    db_connection = {
        'host':'localhost',
        'user':'root',
        'passwd':'',
        'database':'ta_application',
         'port':3305

        }
    db_connection  = mysql.connector.connect(**db_connection)
    my_database=db_connection.cursor(dictionary=True)
    sql_query="SELECT {} FROM {} WHERE status='1' AND user_email='{}'".format(fields, tablename, userData['user_email'])
    print(sql_query)
    try:
        my_database.execute(sql_query)
        output=my_database.fetchone()
    except Exception as err:
        print("exception error message2---->", err)
        output="Failed"
    finally:    
        my_database.close()
        db_connection.close()
    print("user_details",output)
    return output



def delete_records(table_name, condition):
    # db_connection = {
    #     'host':'10.11.12.102',
    #     'user':'ta_application',
    #     'passwd':'Machint@123',
    #     'database':'ta_application'
    #     }
    db_connection = {
        'host':'localhost',
        'user':'root',
        'passwd':'',
        'database':'ta_application',
        'port':3305

        }
    db_connection = mysql.connector.connect(**db_connection)
    my_database = db_connection.cursor()
    condition_data = ""
    for key, value in condition.items():
        if key != "password" and value != "":
            if isinstance(value, str):
                condition_data += " {}='{}' AND".format(key, value)
            else:
                condition_data += " {}={} AND".format(key, value)  
    len_of_condition=len(condition_data)
    condition_data=condition_data[:(len_of_condition-3)]
    try:
        sql_query = "DELETE FROM {} WHERE {}".format(table_name, condition_data)
        my_database.execute(sql_query)
        db_connection.commit()
        retVal="Success"
        print("Records deleted successfully.")
    except Exception as err:
        retVal="Failed"
        print("Exception error message:", err)
    finally:
        my_database.close()
        db_connection.close()
    return retVal
    

def otp_store_into_table(table_name,fields,user_data):
    # db_connection = {
    #     'host':'10.11.12.102',
    #     'user':'ta_application',
    #     'passwd':'Machint@123',
    #     'database':'ta_application'
    #     }
    db_connection = {
        'host':'localhost',
        'user':'root',
        'passwd':'',
        'database':'ta_application',
        'port':3305

        }
    user_email = user_data["user_email"]
    if not user_email:
        msg = 'user_email address and mobile number are required.'
        return msg
    otp = str(random.randint(100000, 999999))
    user_data['phone_number'] = "1234567890"
    user_data['otp'] = otp
    
    
    user_all_data='","'.join(user_data.values())
    user_all_data='"' + user_all_data + '"'

 
    db_connection  = mysql.connector.connect(**db_connection)

    my_database=db_connection.cursor()
    sql_query="INSERT INTO {}({}) VALUES({})".format(table_name, fields, user_all_data)
    print(sql_query)

    try:
        my_database.execute(sql_query)
        db_connection.commit()
        my_database.execute("SELECT LAST_INSERT_ID()")   
        last_inserted_id=my_database.fetchone()  
        last_inserted_id=last_inserted_id[0]
        
        # Send OTP to user_email address
        # resp_mail = send_user_email('ganesh.gk818508@gmail.com', f'Your OTP for login is: {otp}')
        resp_mail = send_opt_to_user_email_for_reset_password(user_data)
        print(resp_mail,"mail=====================================>")
        
        retVal={"message": resp_mail["message"],"status_code":"200"}
    except Exception as err:
        print("exception error message---->", err)
        retVal={"message": "Failed"}
    finally:    
        my_database.close()
        db_connection.close()
    return retVal

#Get Column Data types from database for any table

def get_columns_datatypes(database_name, table_name):
    # db_connection = {
    #     'host':'10.11.12.102',
    #     'user':'ta_application',
    #     'passwd':'Machint@123',
    #     'database':'ta_application'
    #     }
    db_connection = {
        'host':'localhost',
        'user':'root',
        'passwd':'',
        'database':'ta_application',
        'port':3305

        }
    db_connection  = mysql.connector.connect(**db_connection)
    my_database=db_connection.cursor(dictionary=True)
    sql_query="SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '{}' AND TABLE_NAME = '{}'".format(database_name, table_name)
    print(sql_query)
    try:
        my_database.execute(sql_query)
        output=my_database.fetchall()
    except Exception as err:
        print("exception error ...>", err)
        output={"Error": "Error ocuured at database"}
    finally:
        db_connection.close()
        my_database.close()
    return output


# I Register User

def register_user_now(table_name, fields, user_data):
    # db_connection = {
    #     'host':'10.11.12.102',
    #     'user':'ta_application',
    #     'passwd':'Machint@123',
    #     'database':'ta_application'
    #     }
    db_connection = {
        'host':'localhost',
        'user':'root',
        'passwd':'',
        'database':'ta_application',
        'port':3305

        }
    
    db_connection  = mysql.connector.connect(**db_connection)
    my_database=db_connection.cursor()
    employee_id=user_data['employee_id'].lower()
    useremail=user_data['user_email']
    phone_number = user_data['phone_number']
    userpassword=user_data['password']
    hashed_password=generate_password_hash(userpassword)
    user_data['password']=hashed_password
    
    user_all_data='","'.join(user_data.values())
    user_all_data='"' + user_all_data + '"'
    try:
        query_for_user_existence="SELECT * FROM {} WHERE employee_id='{}'".format(table_name, employee_id)
        if not email_verification(useremail):
            msg='Invalid Email Address !'
        elif not username_verification(employee_id):
            msg='Employee Id must contain only characters and numbers !'
        elif not mobile_number_verification(phone_number):
            msg = "Invalid Mobile Number !"    
        elif (not employee_id) or (not userpassword) or (not useremail) or (not phone_number):
            msg='Please provide the complete details !'
        elif employee_id:
            try:
                my_database.execute(query_for_user_existence)
                user_exist=my_database.fetchone()
                if user_exist:
                    msg='User already exists!'
                else:
                    sql_query="INSERT INTO {}({}) VALUES({})".format(table_name, fields,user_all_data)
                    try:
                        my_database.execute(sql_query)
                        db_connection.commit()
                        msg='User Register/Created Successfully !'
                    except Exception as err:
                        print("database error", err)
                        msg='Failed'
                    finally:    
                        my_database.close()
                        db_connection.close()   
            except Exception as err:
                print("database error", err)
                msg='Failed'
            finally:    
                my_database.close()
                db_connection.close()
    except Exception as err:
        print("database error", err)
        msg='Failed'
    finally:    
        my_database.close()
        db_connection.close()
    return msg

def get_user(table_name, fields, user_data):
    # db_connection = {
    #     'host':'10.11.12.102',
    #     'user':'ta_application',
    #     'passwd':'Machint@123',
    #     'database':'ta_application'
    #     }
    db_connection = {
        'host':'localhost',
        'user':'root',
        'passwd':'',
        'database':'ta_application',
        'port':3305


        }
    db_connection  = mysql.connector.connect(**db_connection)
    my_database=db_connection.cursor(dictionary=True)
    condition_data = ""
    for key, value in user_data.items():
        if key != "password" and value != "":
            if isinstance(value, str):
                condition_data += " {}='{}' AND".format(key, value)
            else:
                condition_data += " {}={} AND".format(key, value)  
    len_of_condition=len(condition_data)
    condition_data=condition_data[:(len_of_condition-3)]
    sql_query="SELECT {} FROM {} WHERE {}".format(fields, table_name, condition_data)
    print(sql_query,"=================>>>")
    try:
        my_database.execute(sql_query)
        output=my_database.fetchone()
    except Exception as err:
        print("database error", err)
        output="Failed"
    finally:    
        my_database.close()
        db_connection.close()
    print("user_details",output)
    return output



def returnspecificlist(field, tablename, args=None):
    # db_connection = {
    #     'host':'10.11.12.102',
    #     'user':'ta_application',
    #     'passwd':'Machint@123',
    #     'database':'ta_application'
    #     }
    db_connection = {
        'host':'localhost',
        'user':'root',
        'passwd':'',
        'database':'ta_application',
        'port':3305

        }
    my_database=db_connection.cursor(dictionary=True)
    sql_query="SELECT {} FROM {}".format(field, tablename)
    print(sql_query)
    final_stored_column_data_list=[]
    try:
        my_database.execute(sql_query, args)
        stored_column_data=my_database.fetchall()
        for name_dict in stored_column_data:
            final_stored_column_data_list.append(name_dict[field])
    except Exception as err:
        print("exception error message---->", err)
        final_stored_column_data_list=[]
    finally:    
        my_database.close()
        db_connection.close()
    return final_stored_column_data_list

#CREATE======>
def insert_into_table(tablename, fields, data,args=None):
    # db_connection = {
    #     'host':'10.11.12.102',
    #     'user':'ta_application',
    #     'passwd':'Machint@123',
    #     'database':'ta_application'
    #     }
   
    db_connection = {
        'host':'localhost',
        'user':'root',
        'passwd':'',
        'database':'ta_application',
                'port':3305

        }
    print("I am now at dbilayer")
    # final_stored_names_list=returnspecificlist(namefield, tablename)
    # print(final_stored_names_list)
    my_database=db_connection.cursor()
    sql_query="INSERT INTO {}({}) VALUES({})".format(tablename, fields, data)
    print(sql_query)
    # print(final_stored_names_list)
    try:
        my_database.execute(sql_query, args)
        db_connection.commit()
        my_database.execute("SELECT LAST_INSERT_ID()")   
        last_inserted_id=my_database.fetchone()  
        last_inserted_id=last_inserted_id[0]
        retVal={"message": "Success", "last_insert_id": last_inserted_id}
    except Exception as err:
        print("exception error message---->", err)
        retVal={"message": "Failed", "last_insert_id": None}
    finally:    
        my_database.close()
        db_connection.close()
    return retVal


# Read without condition
def read_all_without_condition(table_name, args=None):
    # db_connection = {
    #     'host':'10.11.12.102',
    #     'user':'ta_application',
    #     'passwd':'Machint@123',
    #     'database':'ta_application'
    #     }
    db_connection = {
        'host':'localhost',
        'user':'root',
        'passwd':'',
        'database':'ta_application',
        'port':3305

        }
    db_connection  = mysql.connector.connect(**db_connection)
    my_database=db_connection.cursor(dictionary=True)
    sql_query="SELECT * FROM {}".format(table_name)
    print(sql_query)
    final_stored_column_data_list=[]
    try:
        my_database.execute(sql_query, args)
        stored_column_data=my_database.fetchall()
        final_stored_column_data_list = stored_column_data
    except Exception as err:
        print("exception error message---->", err)
        final_stored_column_data_list=[]
    finally:    
        my_database.close()
        db_connection.close()
    return final_stored_column_data_list

# Read many with condition
def read_recent_five(table_name):
    
    # db_connection = {
    #     'host':'10.11.12.102',
    #     'user':'ta_application',
    #     'passwd':'Machint@123',
    #     'database':'ta_application'
    #     }
    db_connection = {
        'host': 'localhost',
        'user': 'root',
        'passwd': '',
        'database': 'ta_application',
        'port':3305

    }
    db_connection = mysql.connector.connect(**db_connection)
    my_database = db_connection.cursor(dictionary=True)
    sql_query = f"SELECT * FROM {table_name} WHERE status=1 ORDER BY last_modified DESC LIMIT 5"
    print(sql_query)
    final_stored_column_data_list = []
    try:
        my_database.execute(sql_query)
        stored_column_data = my_database.fetchall()
        final_stored_column_data_list = stored_column_data
    except Exception as err:
        print("exception error message---->", err)
        final_stored_column_data_list = []
    finally:
        my_database.close()
        db_connection.close()
    return final_stored_column_data_list

def read_with_condition(table_name, fields, condition, args=None):
    # db_connection = {
    #     'host':'10.11.12.102',
    #     'user':'ta_application',
    #     'passwd':'Machint@123',
    #     'database':'ta_application'
    #     }
    db_connection = {
        'host':'localhost',
        'user':'root',
        'passwd':'',
        'database':'ta_application',
        'port':3305

        }
    db_connection  = mysql.connector.connect(**db_connection)
    my_database=db_connection.cursor(dictionary=True)
    # condition_data=''
    # for key, value in condition.items():
    #     if isinstance(value, str):
    #         condition_data += " {}='{}' AND".format(key, value)
    #     else:
    #         condition_data += " {}={} AND".format(key, value)
    # len_of_condition=len(condition_data)
    # condition_data=condition_data[:(len_of_condition-3)]
    sql_query="SELECT {} FROM {} WHERE {}".format(fields, table_name, condition)
    print(sql_query)
    output=[]
    try:
        my_database.execute(sql_query, args)
        output=my_database.fetchall()  
    except Exception as err:
        print("exception error message---->", err)
        output = {"Error":"No Data Recieved or Error Occured"}
    finally:    
        my_database.close()
        db_connection.close()
    return output


def read_with_condition_pagination(table_name, fields, condition,page_number, page_size, args=None):
    # db_connection = {
    #     'host':'10.11.12.102',
    #     'user':'ta_application',
    #     'passwd':'Machint@123',
    #     'database':'ta_application'
    #     }
    db_connection = {
        'host':'localhost',
        'user':'root',
        'passwd':'',
        'database':'ta_application',
        'port':3305

        }
    offset = page_size * (page_number - 1)
    db_connection  = mysql.connector.connect(**db_connection)
    my_database=db_connection.cursor(dictionary=True)
    sql_query = "SELECT {} FROM {} WHERE {} ORDER BY candidate_id LIMIT {} OFFSET {}".format(fields,table_name,condition,page_size,offset)
    print(sql_query)
    output=[]
    try:
        my_database.execute(sql_query, args)
        output=my_database.fetchall()  
    except Exception as err:
        print("exception error message---->", err)
        output = {"Error":"No Data Recieved or Error Occured"}
    finally:    
        my_database.close()
        db_connection.close()
    return output

#insert
def insert_into_table(table_name, fields, data, args=None):
    # db_connection = {
    #     'host':'10.11.12.102',
    #     'user':'ta_application',
    #     'passwd':'Machint@123',
    #     'database':'ta_application'
    #     }
    db_connection = {
        'host':'localhost',
        'user':'root',
        'passwd':'',
        'database':'ta_application',
        'port':3305

        }
    db_connection  = mysql.connector.connect(**db_connection)

    my_database=db_connection.cursor()
    sql_query="INSERT INTO {}({}) VALUES({})".format(table_name, fields, data)
    print(sql_query)

    try:
        my_database.execute(sql_query, args)
        db_connection.commit()
        my_database.execute("SELECT LAST_INSERT_ID()")   
        last_inserted_id=my_database.fetchone()  
        last_inserted_id=last_inserted_id[0]
        retVal={"message": "Success", "last_insert_id": last_inserted_id}
    except Exception as err:
        print("exception error message---->", err)
        retVal={"message": "Failed", "last_insert_id": None}
    finally:    
        my_database.close()
        db_connection.close()
    return retVal

#Update and Delete(status=1(active),0(inactive/delete))
def update_table(table_name, update_data, condition, args=None):
    # db_connection = {
    #     'host':'10.11.12.102',
    #     'user':'ta_application',
    #     'passwd':'Machint@123',
    #     'database':'ta_application'
    #     }
    
    db_connection = {
        'host':'localhost',
        'user':'root',
        'passwd':'',
        'database':'ta_application',
        'port':3305

        }
    db_connection  = mysql.connector.connect(**db_connection)
    my_database=db_connection.cursor()
    
    # condition_data=''
    # print(condition,"=========================>>>>>>>>")
    # for key, value in condition.items():
    #     if isinstance(value, str):
    #         condition_data += " {}='{}' AND".format(key, value)
    #     else:
    #         condition_data += " {}={} AND".format(key, value)
    # len_of_condition=len(condition_data)
    # condition_data=condition_data[:(len_of_condition-3)]
    
    
    # final_to_be_updated_data=''
    # for key, value in update_data.items():
    #     if isinstance(value, str):
    #         final_to_be_updated_data += "{}='{}',".format(key,value)
    #     else:
    #         final_to_be_updated_data += "{}={},".format(key,value)
    # final_to_be_updated_data=final_to_be_updated_data.rstrip(final_to_be_updated_data[-1])
    sql_query="UPDATE {} SET {} WHERE {}".format(table_name, update_data, condition)
    print(sql_query)
    try:
        my_database.execute(sql_query, args)
        db_connection.commit()
        retVal="Success"
    except Exception as err:
        print("exception error message---->", err)
        retVal="Failed"
    finally:    
        my_database.close()
        db_connection.close()
    return retVal

def get_interview_schedules(condition,args=None):
    print(condition)
    # db_connection = {
    #     'host':'10.11.12.102',
    #     'user':'ta_application',
    #     'passwd':'Machint@123',
    #     'database':'ta_application'
    #     }
    db_connection = {
        'host':'localhost',
        'user':'root',
        'passwd':'',
        'database':'ta_application',
        'port':3305

        }
    db_connection  = mysql.connector.connect(**db_connection)
    my_database=db_connection.cursor(dictionary=True)
    sql_query = "SELECT interview_schedule.*,interview_candidates.* FROM interview_schedule JOIN interview_candidates ON interview_candidates.candidate_id = interview_schedule.candidate_id WHERE interview_schedule.status=1 AND interview_candidates.status=1"
    print(sql_query)
    output=[]
    try:
        my_database.execute(sql_query, args)
        output=my_database.fetchall()  
    except Exception as err:
        print("exception error message---->", err)
        output = {"Error":"No Data Recieved or Error Occured"}
    finally:    
        my_database.close()
        db_connection.close()
    return output

def get_onboards(condition,args=None):
    print(condition)
    # db_connection = {
    #     'host':'10.11.12.102',
    #     'user':'ta_application',
    #     'passwd':'Machint@123',
    #     'database':'ta_application'
    #     }
    db_connection = {
        'host':'localhost',
        'user':'root',
        'passwd':'',
        'database':'ta_application',
        'port':3305

        }
    db_connection  = mysql.connector.connect(**db_connection)
    my_database=db_connection.cursor(dictionary=True)
    sql_query = "SELECT onboard.*,interview_candidates.* FROM onboard JOIN interview_candidates ON interview_candidates.candidate_id = onboard.candidate_id WHERE onboard.status=1 AND interview_candidates.status=1"
    print(sql_query)
    output=[]
    try:
        my_database.execute(sql_query, args)
        output=my_database.fetchall()  
    except Exception as err:
        print("exception error message---->", err)
        output = {"Error":"No Data Recieved or Error Occured"}
    finally:    
        my_database.close()
        db_connection.close()
    return output