from datetime import datetime, date
from core.dbil import dbilayer

################ Think once is it required to convert datetime, date datatypes while inserting, updating

#Get Data Type from Database& convert data to insert into

def convert_data_types_for_insert(database_name, table_name, data):
    column_datas=dbilayer.get_columns_datatypes(database_name, table_name)
    print("all column types",column_datas,"length===",len(column_datas))
    print("request data",data)
    final_data_to_insert_into_db=''
    for key,value in data.items():
        if (key == 'id'):
            pass
        else:
            for column_dict in column_datas:
                if (key == column_dict['COLUMN_NAME']):
                    if ((column_dict['DATA_TYPE'] == 'int') or (column_dict['DATA_TYPE'] == 'bigint')or (column_dict['DATA_TYPE'] == 'tinyint') or (column_dict['DATA_TYPE'] == 'smallint') or (column_dict['DATA_TYPE'] == 'decimal')):
                        if value != "":
                            final_data_to_insert_into_db += "{},".format(int(value))
                        else:
                            final_data_to_insert_into_db += "{},".format('NULL')
                                
                    elif ((column_dict['DATA_TYPE'] == 'longtext') or (column_dict['DATA_TYPE'] == 'tinyint') or (column_dict['DATA_TYPE'] == 'varchar') or (column_dict['DATA_TYPE'] == 'text') or (column_dict['DATA_TYPE'] == 'datetime') or (column_dict['DATA_TYPE'] == 'date') or (column_dict['DATA_TYPE'] == 'time')):
                        if value !="":
                            final_data_to_insert_into_db += "'{}',".format(value)
                        else:
                            final_data_to_insert_into_db += "{},".format('NULL')
    # print(final_data_to_insert_into_db,"data to insert=============")

                    
    final_data_to_insert_into_db=final_data_to_insert_into_db.rstrip(final_data_to_insert_into_db[-1])
    print("final_data_to_insert in function",final_data_to_insert_into_db)
    return final_data_to_insert_into_db

#Get Data Type from Database& update data

def convert_data_types_for_update(database_name, table_name, data):
    column_datas=dbilayer.get_columns_datatypes(database_name, table_name)
    print("all column types",column_datas)
    print("request data",data)
    final_data_to_be_updated_db=''

    for key, value in data.items():
        for column_dict in column_datas:
                if (key == column_dict['COLUMN_NAME']):
                    if ((column_dict['DATA_TYPE'] == 'int') or (column_dict['DATA_TYPE'] == 'bigint')or (column_dict['DATA_TYPE'] == 'tinyint') or (column_dict['DATA_TYPE'] == 'smallint') or (column_dict['DATA_TYPE'] == 'decimal')):
                        final_data_to_be_updated_db += "{}={},".format(key,value)
                    elif ((column_dict['DATA_TYPE'] == 'longtext')  or (column_dict['DATA_TYPE'] == 'varchar') or (column_dict['DATA_TYPE'] == 'text') or (column_dict['DATA_TYPE'] == 'datetime') or (column_dict['DATA_TYPE'] == 'date')):
                        final_data_to_be_updated_db += "{}='{}',".format(key,value)     
    final_data_to_be_updated_db=final_data_to_be_updated_db.rstrip(final_data_to_be_updated_db[-1])
    print("final_data_to_update",final_data_to_be_updated_db)
    return final_data_to_be_updated_db

#Get Data Type from Database& conditional data

def convert_data_types_for_conditions(database_name, table_name, data):
    column_datas=dbilayer.get_columns_datatypes(database_name, table_name)
    print("all column types",column_datas)
    print("condition data",data)
    condition_data=''

    for key, value in data.items():
        for column_dict in column_datas:
                if (key == column_dict['COLUMN_NAME']):
                    if ((column_dict['DATA_TYPE'] == 'int') or (column_dict['DATA_TYPE'] == 'bigint')or (column_dict['DATA_TYPE'] == 'tinyint') or (column_dict['DATA_TYPE'] == 'smallint') or (column_dict['DATA_TYPE'] == 'decimal')):
                        condition_data +=  " {}={} AND".format(key, value)
                    elif ((column_dict['DATA_TYPE'] == 'longtext') or (column_dict['DATA_TYPE'] == 'varchar') or (column_dict['DATA_TYPE'] == 'text') or (column_dict['DATA_TYPE'] == 'datetime') or (column_dict['DATA_TYPE'] == 'date') or (column_dict['DATA_TYPE'] == 'timestamp')):
                        condition_data += " {}='{}' AND".format(key, value)     
    len_of_condition=len(condition_data)
    condition_data=condition_data[:(len_of_condition-3)]
    print("condition_date",condition_data)
    return condition_data