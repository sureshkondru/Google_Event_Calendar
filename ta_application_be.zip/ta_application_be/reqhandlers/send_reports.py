from core.dbil import dbilayer
from core.sendemailtousers import send_reports
from core import constants

def send_user_reports():
    data_usage_reports=dbilayer.getreportsdata()
    top_five_data_users=dbilayer.getreports_top_five_users_datausage()
    last_week_data_usage=dbilayer.getreports_datausage_of_week()
    last_week_data_usage_hour=dbilayer.getreports_datausage_of_week_hour()

    # user_emails_list=['rajesh@machint.com','sureshbabu@machint.com','pratap@machint.com','kalyan@machint.com','vivek.nair@machint.com']
    user_emails_list=['vivek.nair@machint.com','sukanya.kodali@machint.com','rosibabu.bandi@machint.com']
    # user_emails_list=['rosibabu.bandi@machint.com']


    if ((data_usage_reports is not None) and (isinstance(data_usage_reports, dict))):
        print(data_usage_reports)
        status_of_data_usgae_of_users=send_reports(user_emails_list,'all_users_data',data_usage_reports['data_usage_of_users'])
        status_of_top_five_data_users=send_reports(user_emails_list,'top_five_users_data',top_five_data_users['top_five_memory_used_users'])
        status_of_week_usage=send_reports(user_emails_list,'daily_usage',last_week_data_usage['daily_data_usage'])
        status_of_week_usage_hour=send_reports(user_emails_list,'daily_usage_hour',last_week_data_usage_hour['daily_data_usage_hour'])
        reports_mails_status=''
        if (status_of_data_usgae_of_users == "Success"):
            reports_mails_status="Mail for data usage of All users sent Successfully"
        elif(status_of_top_five_data_users=="Success"):
            reports_mails_status="Mail for data usage of All users, Top five high data using users sent Successfully"
        elif(status_of_week_usage=="Success"):
            reports_mails_status=="Mail for data usage of All users, Top five high data using users, Last Week day by day data usage sent Successfully"
        elif(status_of_week_usage_hour=="Success"):
            reports_mails_status="Mail for data usage of All users, Top five high data using users,Last Week day by day data usage, Last Week day by day data usage by hour sent Successfully"
        print("Mail Sent Status...>", reports_mails_status)
    else:
        print("Error Occured at Database")