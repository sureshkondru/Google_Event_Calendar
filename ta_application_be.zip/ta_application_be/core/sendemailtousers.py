import smtplib, ssl
from csv import DictWriter

from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.mime.text import MIMEText
import smtplib

import smtplib
from email.message import EmailMessage


# # Email credentials
# email = 'ganesh.ias212@gmail.com'
# password = '9494399128'
# smtp_server = 'smtp.gmail.com'
# smtp_port = 587

# def send_email(email_address, message):
#     try:
#         msg = MIMEMultipart()
#         msg['From'] = email
#         msg['To'] = email_address
#         msg['Subject'] = 'OTP for Login'
#         msg.attach(MIMEText(message, 'plain'))

#         server = smtplib.SMTP(smtp_server, smtp_port)
#         server.starttls()
#         server.login(email, password)
#         server.send_message(msg)
#         server.quit()
#         response="Success"
#     except Exception as err:
#         print("error message1......>",err)
#         response="Failed"
#     return response
    

def send_opt_to_user_email_for_reset_password(user_details):
    try:
        print("user details", user_details)
        sender_email = "alerts@machint.com"
        sender_password = 'Mac&Vel#9903*'
        receiver_email= user_details['user_email']
        print("receiver email",  receiver_email)
        otp=user_details['otp']
        message = f'Subject: Your OTP for Reset Password is: {otp}'
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email,receiver_email, message)
        response = {"message":"Success"}
    except Exception as err:
        print("error message1......>",err)
        response="Failed"
    return response
    
#===============================================================
def send_otp_to_user_register_user(user_details):
    try:
        print("user details", user_details)
        sender_email = "alerts@machint.com"
        sender_password = 'Mac&Vel#9903*'
        receiver_email= user_details['useremail']
        print("receiver email",  receiver_email)
        username=user_details['username']
        userpassword=user_details['password']
        planvalidity=user_details['plan_validity']
        message = f'Subject: User Login Credentials\n\nYour Username: {username}\nYour Password: {userpassword} \n Plan Expiry Date: {planvalidity}\n\nNote: Please change your password immidiately'
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email,receiver_email, message)
        response="Success"
    except Exception as err:
        print("error message1......>",err)
        response="Failed"
    return response

def send_confirmation_to_user_after_payment(plan_details):
    try:
        sender_email = "alerts@machint.com"
        sender_password = 'Mac&Vel#9903*'
        receiver_email= plan_details['useremail']
        print("receiver email",  receiver_email)
        recharge_activated_date=plan_details['recharge_activated_date']
        recharge_due_date=plan_details['recharge_due_date']
        no_of_plan_validity_days=plan_details['plan_validity_days']
        message = f'Subject: Recharge Plan Details\n\nPlan Activated Date: {recharge_activated_date}\nYour Plan Expiry Date: {recharge_due_date}\n\nPlan Validity Days: {no_of_plan_validity_days}\n\nNote: Please Check Your Plan Details'
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email,receiver_email, message)
        response="Success"
    except Exception as err:
        print("error message1......>",err)
        response="Failed"
    return response

def send_plan_expiry_dates(user_recharge_details):
    try:
        sender_email = "alerts@machint.com"
        sender_password = 'Mac&Vel#9903*'
        receiver_email= user_recharge_details['useremail']
        print("receiver email",  receiver_email)
        recharge_activated_date=user_recharge_details['recharge_activated_date']
        recharge_due_date=user_recharge_details['recharge_due_date']
        plan_expires_within=user_recharge_details['plan_expires_within']
        message = f'Subject: Recharge Expiry Plan Details\n\nPlan Activated Date: {recharge_activated_date}\nYour Plan Expiry Date: {recharge_due_date}\n\nPlan Expires Within Days: {plan_expires_within}\n\nNote: Please Recharge Immidiately to avoid connection loss'
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email,receiver_email, message)
        response="Success"
    except Exception as err:
        print("error message1......>",err)
        response="Failed"
    return response

def send_reports(user_emails_list,fields_name,weekly_reports_data):
    try:
        EMAIL_ADDRESS = "alerts@machint.com"
        EMAIL_PASSWORD = 'Mac&Vel#9903*'

        if ((fields_name == 'all_users_data') or (fields_name == 'top_five_users_data')):
            fields=('ACCOUNT_NAME','COMPANY_NAME','MEMORY_USED','NUMBER_OF_FILES_STORED')
        elif (fields_name == 'daily_usage'):
            fields=('DATE','ACCOUNT_NAME','COMPANY_NAME','MEMORY_USED','NUMBER_OF_FILES_STORED')
        elif (fields_name == 'daily_usage_hour'):
            fields=('HOUR','ACCOUNT_NAME','COMPANY_NAME','MEMORY_USED','NUMBER_OF_FILES_STORED')

        msg = EmailMessage()
        msg['Subject'] = 'Weekly Reports Data for File Upload& Download'
        msg['From'] = EMAIL_ADDRESS 
        msg['To'] = user_emails_list
        msg.set_content('Please find the attachemnt below of Users Usage Report of File Upload& Download')

        with open('data_reports.csv','w') as output_file:
            writer = DictWriter(output_file, (fields))
            writer.writeheader()
            writer.writerows(weekly_reports_data)
        with open('data_reports.csv', 'rb') as created_file:
            msg.add_attachment(created_file.read(),maintype='application', subtype='octet-stream', filename=output_file.name)

        # context = ssl.create_default_context()

        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
            smtp.login(EMAIL_ADDRESS, EMAIL_PASSWORD) 
            smtp.send_message(msg)

        response="Success"
    except Exception as err:
        print("error message1......>",err)
        response="Failed"
    return response