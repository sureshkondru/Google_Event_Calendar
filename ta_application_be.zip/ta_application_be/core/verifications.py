import re

def email_verification(useremail):
    if re.fullmatch(r'[^@]+@[^@]+\.[^@]+', useremail):
        return True
    else:
        return False
    
def username_verification(username):
    if re.fullmatch(r'[A-Za-z0-9]+', username):
        return True
    else:
        return False
    
def mobile_number_verification(mobile_number):
    pattern = r'^\d{10}$'
    if re.fullmatch(pattern, mobile_number):
        return True
    else:
        return False