from core.bll import bllengine
from reqhandlers.create_google_event import create_event,send_mail_to_attendees 
import pytz
tz_UTC = pytz.timezone('UTC')
import base64
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import datetime
from datetime import datetime, timedelta,timezone
import pickle
import os.path
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
import smtplib, ssl
from smtplib import SMTP          
from googleapiclient.errors import HttpError
from email.mime.application import MIMEApplication
from email.message import EmailMessage
from reqhandlers.handling_datetime import get_current_timestamp
from reqhandlers.cal_setup import get_calendar_service
import uuid


def send_email_to_attendees(request_data):
    candidate_id = request_data["candidate_id"]
    interviewer = request_data["interviewer"]
    mail_subject = request_data["mail_subject"]
    mail_body = request_data["mail_body"]
    candidate_condition = {"request_data":{"candidate_id":candidate_id},"request_id": 21835674,
    "request_src": "ui",
    "request_type": "listdata"}
    candidate_data = bllengine.candidate_readAllCond(candidate_condition)
    # print(candidate_data,"data===============================")
    resp_candidate_data = candidate_data["response"]
    print(resp_candidate_data,"resp data========")
    candidate_name = candidate_data["response"]["data"][0]["first_name"]
    candidate_email = candidate_data["response"]["data"][0]["personal_email"]

    interviewer_condition = {"request_data":{"interviewer":interviewer},"request_id": 21835674,
    "request_src": "ui",
    "request_type": "listdata"}
  
    interviewer_data = bllengine.interviewer_readAllCond(interviewer_condition)
    interviewer_email = interviewer_data["response"]["data"][0]["interviewer_email"]
    interviewer_name = interviewer_data["response"]["data"][0]["interviewer"]
    loop_list_to_send_mail = [{"email":candidate_email,"mail_subject":mail_subject,"mail_body":mail_body},{"email":interviewer_email,"mail_subject":mail_subject,"mail_body":mail_body}]
    mail_count = 0
    for attendee in loop_list_to_send_mail:
        resp = send_mail_to_attendees(attendee)
        if resp == "Success":
            mail_count += 1
    if mail_count >=2:
        return {"message":"Success"}
    else:
        return {"message":"Failed"}



def generate_google_link(data):
    resp = create_event(data)
    return resp

def template_email_update_interview(request_data):
    print("template email=========")
    candidate_id = request_data["candidate_id"]
    interviewer = request_data["interviewer"]
    round_type = request_data["round_type"]
    round_name = request_data["round_name"]
    date = request_data["date"]
    start_time = request_data["start_time"]
    end_time = request_data["end_time"]
    sender_email = request_data["sender_email"]
    location = "Machint Solutions Pvt Ltd 1st floor, Lotus Arcadia B Block, Laxmi Cyber City, Whitefields, Kondapur, Telangana 500081."
    candidate_condition = {"request_data":{"candidate_id":candidate_id},"request_id": 21835674,
    "request_src": "ui",
    "request_type": "listdata"}
    candidate_data = bllengine.candidate_readAllCond(candidate_condition)
    # print(candidate_data,"data===============================")
    resp_candidate_data = candidate_data["response"]
    print(resp_candidate_data,"resp data========")
    candidate_name = candidate_data["response"]["data"][0]["first_name"]
    candidate_email = candidate_data["response"]["data"][0]["personal_email"]

    interviewer_condition = {"request_data":{"interviewer":interviewer},"request_id": 21835674,
    "request_src": "ui",
    "request_type": "listdata"}
  
    interviewer_data = bllengine.interviewer_readAllCond(interviewer_condition)
    interviewer_email = interviewer_data["response"]["data"][0]["interviewer_email"]
    interviewer_name = interviewer_data["response"]["data"][0]["interviewer"]

    if request_data["round_type"] == "Face To Face":
        #for candidate
        # google_meetLink_id = 
        
        location = location
        candidate_mail_subject = f"Interview for {round_type} - {round_name}"
        candidate_mail_body = (
                    f"""\
                    Dear {candidate_name},
                    \nYour Interview has been re-scheduled for the {round_type} round ({round_name}) on {date}.
                    \nInterview Details:
                    \nInterview Location:{location}              
                    \nDate: {date}
                    \nTime: {start_time} - {end_time}

                    \n\nPlease confirm your availability for the interview.

                    \n\nBest regards,
                    \nTA MACHINT,
                    \n{sender_email}
                    """)
        candidate_out_put = {"candidate_mail_body":candidate_mail_body,"candidate_mail_subject":candidate_mail_subject,"location":location,"event_id":" "}


        # #for interviewer
        # interviewer_mail_subject = f"Interview for {round_type} - {round_name} with {candidate_name}"
        # interviewer_mail_body = (
        #             f"""\
        #             Dear {interviewer_name},
        #             Your Interview with {candidate_name} has been scheduled for the {round_type} round ({round_name}) on {date}.
        #             Interview Details:
        #             Interview Location:{location}                 
        #             Date: {date}
        #             Time: {start_time} - {end_time}
        #             Please confirm your availability for the interview.

        #             Best regards,
        #             {sender_email}
        #             """)
        # interviewer_out_put = {"interviewer_mail_body":interviewer_mail_body}
        return {"data":candidate_out_put,"message":"Success"}
    
    elif request_data["round_type"] == "Virtual":
        
        data_for_generate_link = {}
        data_for_generate_link["summary"] = request_data["summary"]
        data_for_generate_link['start_time']=request_data['date']+'T'+request_data['start_time']
        data_for_generate_link['end_time']=request_data['date']+'T'+request_data['end_time']
        data_for_generate_link['location'] = request_data['location']
        data_for_generate_link['description'] = request_data['description']

        candidate_dict = {}
        candidate_dict["name_of_the_attendee"] = candidate_name
        candidate_dict["email"] = candidate_email
    
        interviewer_dict = {}
        interviewer_dict["name_of_the_attendee"] = interviewer_name
        interviewer_dict["email"] = interviewer_email

        attendees_list = [candidate_dict,interviewer_dict]

        data_for_generate_link["attendees"] = attendees_list
         #for candidate
        google_meetLink_data= generate_google_link(data_for_generate_link)
        if google_meetLink_data["message"] == "Success":
            google_meetLink = google_meetLink_data["meet_link"]
            google_meetLink_id=google_meetLink_data["event_id"]
            print(google_meetLink,"Success generate link============")
            print(google_meetLink_data,"print data")
            candidate_mail_subject = f"Interview for {round_type} - {round_name}"
            candidate_mail_body = (
                        f"""\
                     Dear {candidate_name},
                    \nYour Interview has been re-scheduled for the {round_type} round ({round_name}) on {date}.
                    \nInterview Details:
                    \nInterview Location:{location}              
                    \nDate: {date}
                    \nTime: {start_time} - {end_time}
                    \nPlease join with the following updated link:{google_meetLink} for the interview.

                    \n\nBest regards,
                    \n{sender_email}
                        """)
            # candidate_mail_body = (
            #             f"""\
            #             Dear {candidate_name},
            #             Your Interview has been scheduled for the {round_type} round ({round_name}) on {date}.
            #             Interview Details:             
            #             Date: {date}
            #             Time: {start_time} - {end_time}
            #             Please join with the following link:{google_meetLink} for the interview.

            #             Best regards,
            #             {sender_email}
            #             """)
            candidate_out_put = {"candidate_mail_body":candidate_mail_body,"candidate_mail_subject":candidate_mail_subject,"location":google_meetLink,"event_id":google_meetLink_id}


            # #for interviewer
            # google_meetLink=""
            # interviewer_mail_subject = f"Interview for {round_type} - {round_name} with {candidate_name}"
            # interviewer_mail_body = (
            #             f"""\
            #             Dear {interviewer_name},
            #             Your Interview with {candidate_name} has been scheduled for the {round_type} round ({round_name}) on {date}.
            #             Interview Details:
            #             Date: {date}
            #             Time: {start_time} - {end_time}
            #             Please join with the following link:{google_meetLink} for the interview.

            #             Best regards,
            #             {sender_email}
            #             """)
            # interviewer_out_put = {"interviewer_mail_body":interviewer_mail_body,"interviewer_mail_subject":interviewer_mail_subject}
            return {"data":candidate_out_put,"message":"Success"}
        else:
            return {"message":"Failed"} 
    else:
        return {"message":"Failed"}





def template_email(request_data):
    print("template email=========")
    candidate_id = request_data["candidate_id"]
    interviewer = request_data["interviewer"]
    round_type = request_data["round_type"]
    round_name = request_data["round_name"]
    date = request_data["date"]
    start_time = request_data["start_time"]
    end_time = request_data["end_time"]
    sender_email = request_data["sender_email"]
    location = "Machint Solutions Pvt Ltd 1st floor, Lotus Arcadia B Block, Laxmi Cyber City, Whitefields, Kondapur, Telangana 500081."
    candidate_condition = {"request_data":{"candidate_id":candidate_id},"request_id": 21835674,
    "request_src": "ui",
    "request_type": "listdata"}
    candidate_data = bllengine.candidate_readAllCond(candidate_condition)
    # print(candidate_data,"data===============================")
    resp_candidate_data = candidate_data["response"]
    print(resp_candidate_data,"resp data========")
    candidate_name = candidate_data["response"]["data"][0]["first_name"]
    candidate_email = candidate_data["response"]["data"][0]["personal_email"]

    interviewer_condition = {"request_data":{"interviewer":interviewer},"request_id": 21835674,
    "request_src": "ui",
    "request_type": "listdata"}
  
    interviewer_data = bllengine.interviewer_readAllCond(interviewer_condition)
    interviewer_email = interviewer_data["response"]["data"][0]["interviewer_email"]
    interviewer_name = interviewer_data["response"]["data"][0]["interviewer"]

    if request_data["round_type"] == "Face To Face":
        #for candidate
        # google_meetLink_id = 
        
        location = location
        candidate_mail_subject = f"Interview for {round_type} - {round_name}"
        candidate_mail_body = (
                    f"""\
                    Dear {candidate_name},
                    \nYour Interview has been scheduled for the {round_type} round ({round_name}) on {date}.
                    \nInterview Details:
                    \nInterview Location:{location}              
                    \nDate: {date}
                    \nTime: {start_time} - {end_time}

                    \n\nPlease confirm your availability for the interview.

                    \n\nBest regards,
                    \nTA MACHINT,
                    \n{sender_email}
                    """)
        candidate_out_put = {"candidate_mail_body":candidate_mail_body,"candidate_mail_subject":candidate_mail_subject,"location":location,"event_id":" "}


        # #for interviewer
        # interviewer_mail_subject = f"Interview for {round_type} - {round_name} with {candidate_name}"
        # interviewer_mail_body = (
        #             f"""\
        #             Dear {interviewer_name},
        #             Your Interview with {candidate_name} has been scheduled for the {round_type} round ({round_name}) on {date}.
        #             Interview Details:
        #             Interview Location:{location}                 
        #             Date: {date}
        #             Time: {start_time} - {end_time}
        #             Please confirm your availability for the interview.

        #             Best regards,
        #             {sender_email}
        #             """)
        # interviewer_out_put = {"interviewer_mail_body":interviewer_mail_body}
        return {"data":candidate_out_put,"message":"Success"}
    
    elif request_data["round_type"] == "Virtual":
        
        data_for_generate_link = {}
        data_for_generate_link["summary"] = request_data["summary"]
        data_for_generate_link['start_time']=request_data['date']+'T'+request_data['start_time']
        data_for_generate_link['end_time']=request_data['date']+'T'+request_data['end_time']
        data_for_generate_link['location'] = request_data['location']
        data_for_generate_link['description'] = request_data['description']

        candidate_dict = {}
        candidate_dict["name_of_the_attendee"] = candidate_name
        candidate_dict["email"] = candidate_email
    
        interviewer_dict = {}
        interviewer_dict["name_of_the_attendee"] = interviewer_name
        interviewer_dict["email"] = interviewer_email

        attendees_list = [candidate_dict,interviewer_dict]

        data_for_generate_link["attendees"] = attendees_list
         #for candidate
        google_meetLink_data= generate_google_link(data_for_generate_link)
        if google_meetLink_data["message"] == "Success":
            google_meetLink = google_meetLink_data["meet_link"]
            google_meetLink_id=google_meetLink_data["event_id"]
            print(google_meetLink,"Success generate link============")
            print(google_meetLink_data,"print data")
            candidate_mail_subject = f"Interview for {round_type} - {round_name}"
            candidate_mail_body = (
                        f"""\
                     Dear {candidate_name},
                    \nYour Interview has been scheduled for the {round_type} round ({round_name}) on {date}.
                    \nInterview Details:
                    \nInterview Location:{location}              
                    \nDate: {date}
                    \nTime: {start_time} - {end_time}
                    \nPlease join with the following link:{google_meetLink} for the interview.

                    \n\nBest regards,
                    \n{sender_email}
                        """)
            # candidate_mail_body = (
            #             f"""\
            #             Dear {candidate_name},
            #             Your Interview has been scheduled for the {round_type} round ({round_name}) on {date}.
            #             Interview Details:             
            #             Date: {date}
            #             Time: {start_time} - {end_time}
            #             Please join with the following link:{google_meetLink} for the interview.

            #             Best regards,
            #             {sender_email}
            #             """)
            candidate_out_put = {"candidate_mail_body":candidate_mail_body,"candidate_mail_subject":candidate_mail_subject,"location":google_meetLink,"event_id":google_meetLink_id}


            # #for interviewer
            # google_meetLink=""
            # interviewer_mail_subject = f"Interview for {round_type} - {round_name} with {candidate_name}"
            # interviewer_mail_body = (
            #             f"""\
            #             Dear {interviewer_name},
            #             Your Interview with {candidate_name} has been scheduled for the {round_type} round ({round_name}) on {date}.
            #             Interview Details:
            #             Date: {date}
            #             Time: {start_time} - {end_time}
            #             Please join with the following link:{google_meetLink} for the interview.

            #             Best regards,
            #             {sender_email}
            #             """)
            # interviewer_out_put = {"interviewer_mail_body":interviewer_mail_body,"interviewer_mail_subject":interviewer_mail_subject}
            return {"data":candidate_out_put,"message":"Success"}
        else:
            return {"message":"Failed"} 
    else:
        return {"message":"Failed"}
    


#####Event Cancel/Delete#######
def send_email_notification(template_email):
    sender_email = "ta.dev@machint.com"
    receiver_email = "suresh.kondru@machint.com"
    password = "Machint@dev2024"
    
    message = MIMEMultipart()
    message['From'] = sender_email
    message['To'] = receiver_email
    message['Subject'] = "Google Calendar Event Deleted"

    body = "The event has been successfully deleted from Google Calendar."
    message.attach(MIMEText(body, 'plain'))

    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login(sender_email, password)
    text = message.as_string()
    server.sendmail(sender_email, receiver_email, text)
    server.quit()

def cancel_event(request_data):
    service = get_calendar_service()
    try:
           service.events().delete(
               calendarId=request_data["calendar_id"],
               eventId=request_data['googlemeet_id'],
           ).execute()
    # except googleapiclient.errors.HttpError:
    except HttpError as error:

 
            print("Failed to delete event")

    print("Event deleted")
    send_email_notification()


#### update event ########



    







