from hurry.filesize import size
import humanize

def files_size_conversion(file_sizes_list):
    final_file_size_converted_list=[]
    for each_user in file_sizes_list:
            print("each user...>", each_user)
            each_user_dict={}
            for key, value in each_user.items():
                print("key...value...>",key, value)
                if key == "memory_used":
                    each_user_dict[key]=size(value)
                    # print("data size in gb", value/(1024**3))
                    # bytes_value = 2000000000  # 2 gigabytes in bytes
                    # gigabytes_value = humanize.naturalsize(value, binary=True)
                    # print(gigabytes_value)  # Output: 1.9 GB
                else:
                    each_user_dict[key]=value
            final_file_size_converted_list.append(each_user_dict)
    return final_file_size_converted_list