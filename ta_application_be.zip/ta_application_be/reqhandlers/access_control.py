from core.dbil import dbilayer

#User Details

def user_details(username):
    username={"username": username}
    sta=dbilayer.get_specific_filed('users', '*', username)
    if (sta is not None):
        return sta
    else:
        return {}

#List of users with access having hits

def user_exist_in_access_control():
    sta=dbilayer.returnspecificlist('username', 'user_access_records')
    if (sta is not None):
        return sta
    else:
        return []
    

#User Plan Valid Days

def user_plan_valid_days(username):
    username={"username": username}
    sta=dbilayer.get_specific_filed('user_access_records', '*', username)
    if (sta is not None):
        return sta
    else:
        return {}

#User organization

def user_organization(username):
    username={"username": username}
    sta=dbilayer.get_specific_filed('users', 'company_name', username)
    if (sta is not None):
        return sta
    else:
        return {}

#User Hits Count Reduce

def decrease_user_hits(username):
    sta=dbilayer.decreaseaccesscountswithcond(username)
    if ((sta is not None) and (sta == "Success")):
        return True
    else:
        return False

