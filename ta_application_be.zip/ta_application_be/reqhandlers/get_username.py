from flask_jwt_extended import jwt_required, get_jwt
def get_user_email():
    jwt_info=get_jwt()
    if (len(jwt_info) != 0):
        username=get_jwt()['sub']
    return username